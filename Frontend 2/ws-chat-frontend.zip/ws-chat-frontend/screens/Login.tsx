import React, {
    useState,
} from 'react';
import {
    KeyboardAvoidingView,
    StyleSheet,
    Text,
    TextInput,
    SafeAreaView,
    Button,
    View,
    ToastAndroid,
} from 'react-native';

export interface LoginProps {
    loginSuccessfull: Function,
}

export default function Login({ loginSuccessfull }: LoginProps) {
    const [url, setUrl] = useState("10.0.2.2:8080");
    const [username, setUsername] = useState(null);
    const [password, setPassword] = useState(null);

    const connect = async (type: "register" | "login") => {
        let token

        try {
            const res = await fetch("http://" + url + "/user/" + type, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    username: username,
                    password: password,
                })
            });
            token = await res.text();
        }
        catch (error) {
            ToastAndroid.show("invalid credentials", ToastAndroid.LONG)
        }

        if (token)
            loginSuccessfull({
                server: url,
                token: token,
                username: username,
            })
    }

    return (
        <SafeAreaView style={styles.container}>
            <View>
                <KeyboardAvoidingView>
                    <View>
                        <TextInput placeholder="server address" keyboardType="url" value={url} onChangeText={setUrl} />
                        <TextInput placeholder="username" keyboardType="default" value={username} onChangeText={setUsername} />
                        <TextInput placeholder="password" keyboardType="visible-password" value={password} onChangeText={setPassword} />
                    </View>
                    <View style={styles.buttonContainer}>
                        <Button title="login" onPress={() => connect('login')} />
                        <Button title="register" onPress={() => connect('register')} />
                    </View>
                </KeyboardAvoidingView>
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 20,
        justifyContent: "space-around",
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-around'
    },
})