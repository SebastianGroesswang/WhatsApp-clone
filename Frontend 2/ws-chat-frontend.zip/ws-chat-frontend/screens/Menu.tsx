import React, {

} from 'react';
import { 
    View,
    StyleSheet,
    Text,
    FlatList,
} from 'react-native';
import ChatPreview from '../components/ChatPreview';
import MemberhsipDto from '../models/membership';

export interface MenuProps{
    memberships: MemberhsipDto[],
    switchToChat: Function,
}

export default function Chat(props: MenuProps){
    if(props.memberships.length === 0){
        return <Text style={styles.sadLife}>To be added to a chat, talk to an administrator</Text>
    }

    return(
        <View style={styles.container}>
            <FlatList 
                data={props.memberships}
                renderItem={item => <ChatPreview membership={item.item} onPress={() => props.switchToChat(item.item.id)}/>}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        height: '100%',
        paddingTop: 20,
    },
    sadLife:{
        paddingTop: 20
    }
})