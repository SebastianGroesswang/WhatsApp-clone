import React, {

} from 'react';
import {
    StyleSheet,
    FlatList,
    TouchableOpacity,
    Text,
} from 'react-native'

import MemberhsipDto from "../models/membership";


export interface ChatProps{
    membership: MemberhsipDto,
    onPress: Function,
}

export default function ChatPreview (props: ChatProps) {
    return (
        <TouchableOpacity style={styles.container} onPress={props.onPress}>
            <Text style={styles.text}>{props.membership.name}</Text>
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({
    container: {
        height: '20%',
        borderRadius: 10,
        borderColor: 'gray',
        flex: 1,
        margin: 10,
    },
    text: {
        fontSize: 20,
        flex: 1,
    }
})