export default interface MemberhsipDto {
    id: number,
    name: string,
    joined: number,
}