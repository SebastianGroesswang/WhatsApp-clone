export default interface MessageDto{
    roomId: number,
    username: string,
    message: string, 
    timestamp: Date,
}