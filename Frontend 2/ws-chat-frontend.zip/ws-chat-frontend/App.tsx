import React, {
  useState,
} from 'react';
import Chat from './screens/Chat';
import Login from './screens/Login';
import Menu from './screens/Menu';
import MessageDto from './models/message';
import MembershipDto from './models/membership';

let socket: WebSocket = null;

export default function App() {
  const [nav, setNav] = useState('l')
  const [username, setUsername] = useState('')
  const [memberships, setMemberships] = useState([])
  const [messages, setMessages] = useState([]);
  const [currentChat, setCurrentChat] = useState(null);

  const sendMessage = (msg: string) => {
    let message: MessageDto = {
      message: msg,
      roomId: currentChat,
      timestamp: new Date(Date.now()),
      username: username,
    }
    socket.send(JSON.stringify(message))
  }

  const loginSuccessfull = async ({server, token, username}: {server: string, token: string, username: string}) => {
    setUsername(username);
    socket = new WebSocket("ws://" + server + "/chat/" + token)

    //existing Messages
    const existingMessagesResponse = await fetch("http://"+ server +"/user/existingMessages/" + token);
    const existingMessages: MessageDto[] = await existingMessagesResponse.json();
    setMessages(existingMessages);

    //memberhsips
    const existingMembershipsResponse = await fetch("http://" + server + "/user/memberships/" + token);
    const existingMemberhips: MembershipDto[] = await existingMembershipsResponse.json();
    setMemberships(existingMemberhips);

    socket.onmessage = event => {
      console.log(event.data)
      const msg: MessageDto = JSON.parse(event.data)
      setMessages([...messages, msg])
    }

    setNav('m')
  }

  switch (nav) {
    case 'l': {
      return <Login loginSuccessfull={loginSuccessfull} />
    }
    case 'm': {
      return <Menu memberships={memberships} switchToChat={(id) => {
        setCurrentChat(id)
        setNav('c')
      }}/>
    }
    case 'c': {
      return <Chat messages={messages.filter(msg => msg.roomId === currentChat)} sendMessage={sendMessage} goBack={() => setNav('m')} />
    }
  }
}
